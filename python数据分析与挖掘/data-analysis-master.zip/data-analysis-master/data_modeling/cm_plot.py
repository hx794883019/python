# -*- coding: utf-8 -*-

# cm_plot.py 文件,包括了混淆矩阵可视化函数,
# 放置在python的site-packages 目录,供调用
# 例如:~/anaconda2/lib/python2.7/site-packages

def cm_plot(y, yp):
    from sklearn.metrics import confusion_matrix#导入混淆矩阵函数
    cm = confusion_matrix(y, yp)#混淆矩阵
    import matplotlib.pyplot as plt #导入作图库
    #画混淆矩阵图，配色风格使用cm.Greens，更多风格请参考官网。
    plt.matshow(cm, cmap=plt.cm.Greens)
    plt.colorbar()
    for x in range(len(cm)): #数据标签
        for y in range(len(cm)):
            plt.annotate(cm[x,y], xy=(x, y), horizontalalignment='center', verticalalignment='center')
    plt.ylabel('True label') #坐标轴标签
    plt.xlabel('Predicted label') #坐标轴标签
    return plt
