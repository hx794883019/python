#-*- coding: utf-8 -*-

import numpy as np

a = np.array([2,0,1,5])
print(a)
print(a[:2])
print(a.min())
a.sort()
print(a)
