#-*- coding: utf-8 -*-

print("hello world")

import matplotlib as mpl  
print(mpl.get_cachedir())  